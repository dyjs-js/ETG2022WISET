#!/bin/bash

for i in `seq 45 66`
do
	cp /Users/toursun/Downloads/Bbox_1_new/Bbox_00$i/*.xml ./
done
