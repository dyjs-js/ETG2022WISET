#!/bin/bash

for i in `seq 67 86`
do
	cp /Users/toursun/Downloads/Bbox_1_new/Bbox_00$i/*.xml ./
done
